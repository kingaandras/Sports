﻿namespace Calculator
{
    public class CalculatorItems
    {
        public string firstNumberText;
        public string secondNumberText;
        public string operationText;

        public double firstNumber;
        public double secondNumber;
        public char operation;

        public double result;
    }
}
